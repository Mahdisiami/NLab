%% HW2 Mahdi Siami 98104274

clc; 
close all; 
clear all;

% taking variables
grect = input('Should we show grren and red rectangles for fractals? (Yes = 1, No = 0): ');
infbox = input('Should we show information box in the corner? (Yes = 1, No = 0): ');
subid = input('Please enter the Subject ID: ');
sessionno = input('Please enter session number: ');
screendistance = input('Please enter your eyes distance from screen in cm: ');

% Permutation of fractals, Good Perceptual = 1, Bad Perceptual = 2, Good Value = 3, Bad Value = 4
fper = [ones(12,1); 2.*ones(12,1); 3.*ones(12,1); 4.*ones(12,1);];
fper = fper(randperm(48));

% Loading Fractals from file
Fractals = cell(48,5);
for i = 1:48
    if (i<10)
        filename = ['0',num2str(i),'.jpeg'];
    else
        filename = [num2str(i),'.jpeg'];
    end
    Fractals{i,2} = imread(filename);
    % getting size of fractals
    [Fractals{i,3},Fractals{i,4},Fractals{i,5}] = size(Fractals{i,2});
    Fractals{i,1} = fper(i);
end

fcalss = zeros(48,1);
for i = 1:48
fcalss(i,1) = Fractals{i,1};
end

pgood = find(fcalss == 1);
pbad = find(fcalss == 2);
vgood = find(fcalss == 3);
vbad = find(fcalss == 4);
tempper = zeros(36,1);
for i = 1:12
    tempper( 3*(i - 1) + 1 : 3*i , 1) = i;
end

% Permutation of trials, TP Perceptual = 1, TA Perceptual = 2, TP Value = 3, TA Value = 4
DS = [3,5,7,9]';
inang = 1 : 360;
% perceptual value present absent
ppperm = zeros(1440 , 2 + 9);
paperm = zeros(1440 , 2 + 9);
vaperm = zeros(1440 , 2 + 9);
vpperm = zeros(1440 , 2 + 9);
for i = 1 : 4
    ppperm(360*(i - 1) + 1 : 360*i , 1) = DS(i).*ones(360,1);
    ppperm(360*(i - 1) + 1 : 360*i , 2) = inang';
    paperm(360*(i - 1) + 1 : 360*i , 1) = DS(i).*ones(360,1);
    paperm(360*(i - 1) + 1 : 360*i , 2) = inang';
    vaperm(360*(i - 1) + 1 : 360*i , 1) = DS(i).*ones(360,1);
    vaperm(360*(i - 1) + 1 : 360*i , 2) = inang';
    vpperm(360*(i - 1) + 1 : 360*i , 1) = DS(i).*ones(360,1);
    vpperm(360*(i - 1) + 1 : 360*i , 2) = inang';
end
ppperm = transpose(vpperm(randperm(1440),:)');
paperm = transpose(vpperm(randperm(1440),:)');
vaperm = transpose(vpperm(randperm(1440),:)');
vpperm = transpose(vpperm(randperm(1440),:)');
ppperm = ppperm(1 : 36 , :);
paperm = paperm(1 : 36 , :);
vaperm = vaperm(1 : 36 , :);
vpperm = vpperm(1 : 36 , :);
ppperm(: , 3) = pgood(tempper(randperm(36)));
vpperm(: , 3) = vgood(tempper(randperm(36)));
for i = 1 : 36 
    index = pbad(randperm(12))';
    ppperm(i , 4 : (ppperm(i , 1) + 2)) = index(1 , 1 : (ppperm(i,1) - 1));
    index = vbad(randperm(12))';
    vpperm(i , 4 : (vpperm(i , 1) + 2)) = index(1 , 1 : (vpperm(i,1) - 1));
    index = pbad(randperm(12))';
    paperm(i , 3 : (paperm(i , 1) + 2)) = index(1 , 1 : (paperm(i , 1)));
    index = vbad(randperm(12))';
    vaperm(i , 3 : (vaperm(i , 1) + 2)) = index(1 , 1 : (vaperm(i , 1)));
end
trials = zeros(144,12);

for i = 1:4
    trials(36*(i - 1) + 1 : 36*i , 1) = i;
end
trials(0*36 + 1 : 1*36 , 2 : 12) = ppperm(1 : 36 , :);
trials(1*36 + 1 : 2*36 , 2 : 12) = paperm(1 : 36 , :);
trials(2*36 + 1 : 3*36 , 2 : 12) = vpperm(1 : 36 , :);
trials(3*36 + 1 : 4*36 , 2 : 12) = vaperm(1 : 36 , :);
trials = transpose(trials(randperm(144),:)');

% /////////////////////////// psytoolbox and showing part
PsychDebugWindowConfiguration;
Screen('Preference','SkipSyncTests',1);
[wptr,Screen_size] = Screen('OpenWindow', max(Screen('Screens')),0,[]);
cx = (Screen_size(1) + Screen_size(3))/2;
cy = (Screen_size(2) + Screen_size(4))/2;
rng('shuffle'); 
format long
Fractal_size = 200;
penWidth = 5;
Distance = 380;
Mouse = -1.*ones(144,5);
[Sound,freq] = audioread('Beepsound.wav');
Sound = Sound';
Sound = [Sound; Sound];
InitializePsychSound;
Reward = zeros(144,1);
rejectcount = floor(rand*3 + 2);
Counter = 0;
fractr = 5;
circler = 12;
Result = struct;
Result.Subject_ID = subid;
Result.Session_No = sessionno;
Result.FractalSizeInDegree = atan(fractr/screendistance)*180/pi;
Result.PeripheralCircleDegree = atan(circler/screendistance)*180/pi;
Result.ScreenSize = Screen_size;
Result.Trial_Data = struct;
Result.Trial_Data.ButtonPressed = cell(144,1);
Result.Trial_Data.FractalsName = zeros(144,9);
Result.Trial_Data.FractalsPosition = cell(144,9);
Result.Trial_Data.DS = zeros(144,1);
Result.Trial_Data.ValuePerceptual = cell(144,1);
Result.Trial_Data.TATP = cell(144,1);
Result.Trial_Data.MousePosition = cell(144,1);
% number of trials
for trial_counter = 1 : 36                                 
    % using diagram
    trial = trials(trial_counter,:);
    position = zeros(9,4);
    target_index = 0;
    % Blue fixation circle , [300,500] ms
    Screen('FillOval', wptr , [0 0 255] , [cx - 25 cy - 25 cx + 25 cy + 25]);
    Screen('Flip',wptr); 
    rndtime = (rand*0.2 + 0.3);
    WaitSecs(rndtime);
    % Fixation goes , Fractals show , 3 s
    DS = trial(2);
    Angle = 360/DS;
    inang = trial(3);
    Random_Fractals = randperm(DS);
    Random_Fractals = Random_Fractals + 3;
    for j = 1:DS
        Fractals_Texture = Screen('MakeTexture' , wptr , Fractals{trial(Random_Fractals(j)),2});
        Theta = (((j - 1)*Angle + inang)*2*pi)/360;
        xpic_start = Distance*(cos(Theta)) + cx - Fractal_size/2;
        ypic_start = -1*Distance*(sin(Theta)) + cy - Fractal_size/2;
        xpic_end = Distance*(cos(Theta)) + cx + Fractal_size/2;
        ypic_end = -1*Distance*(sin(Theta)) + cy + Fractal_size/2;
        position(j,:) = [xpic_start ypic_start xpic_end ypic_end];
        Result.Trial_Data.FractalsPosition{trial_counter,j} = position(j,:);
        Screen('DrawTexture' , wptr , Fractals_Texture , [] , position(j,:));
        % Showing Rectangles
            if((trial(1) == 1)||(trial(1) == 3))  
                if (trial(4) == trial(Random_Fractals(j)))
                    if (grect == 1)
                        Screen('FrameRect',wptr,[0 255 0],position(j,:),penWidth);
                    end
                    TP = 1;
                    target_position = position(j,:);
                    target_index = j;
                else
                    if (grect == 1)
                        Screen('FrameRect',wptr,[255 0 0],position(j,:),penWidth);                   
                    end
                end        
            else
                if (grect == 1)
                    Screen('FrameRect' , wptr , [255 0 0] , position(j , :) , penWidth);
                end
                TP = 0;
                target_position = 0;
            end   
    end
    if ((trial_counter > 1)&&(infbox == 1))
        if (Mouse(trial_counter-1,3) == 1)
           Mouse_info = 'ACCEPT PRESS            ';
        end
        if (Mouse(trial_counter-1,5) == 1)
           Mouse_info = 'REJECT PRESS            ';
        end
        if (Error_text == 1)
           Screen('DrawText',wptr,'ERROR! You did not choose anything', 55 , 170 , [255 255 255]); 
        end
        rewardinf = ['REWARD = ', num2str(Reward(trial_counter - 1 , 1)),'              '];
        if ((trials(trial_counter - 1 , 1) == 3)||(trials(trial_counter - 1 , 1) == 4))
            trialinf = 'TRIAL = VALUE GROUP     ';
        else
            trialinf = 'TRIAL = PERCEPTUAL GROUP';
        end
        Screen('TextFont',wptr,'Helvetica');
        Screen('TextSize',wptr,24);
        Screen('DrawText',wptr,Mouse_info,50,80,[255 255 255]);
        Screen('DrawText',wptr,rewardinf,50,110,[255 255 255]);
        Screen('DrawText',wptr,trialinf,50,140,[255 255 255]); 
    end
    Error_text = 0;
    Screen('Flip',wptr);
    % Mouse position 
    finish_time = GetSecs()+3;
    button = 0;
    while ((~button)&(finish_time > GetSecs()))
        [Mouse_x,Mouse_y,button] = GetMouse();
    end
    Mouse(trial_counter,:) = [Mouse_x,Mouse_y,button];   
    check = whereclicked(Mouse(trial_counter,1:2),position,target_index,DS);
    if((sum(Mouse(trial_counter,3:5))==0)||(check == 0))
        % NO PRESS or BLANK AREA PRESS
        % Error beep + 1.5 s ITI
        pahandle = PsychPortAudio('Open',[],[],0,freq,2);
        PsychPortAudio('FillBuffer',pahandle,Sound);
        play_time = PsychPortAudio('Start',pahandle,[],[],1);
        PsychPortAudio('Close',pahandle);
        WaitSecs(1.5);
        Error_text = 1;
    elseif ((Mouse(trial_counter,3) == 1)&&(check == 1))
        % Accept Press, TA or Accept Press, TP, Bad Choice
        % +1 Reward + 1.5 s ITI
        Reward(trial_counter,1) = Reward(trial_counter,1)+1;
        WaitSecs(1.5);
    elseif ((Mouse(trial_counter,3) == 1)&&(check == 2))
        % Accept Press, TP, Good Choice
        % +3 Reward + 1.5 s ITI
        Reward(trial_counter,1) = Reward(trial_counter,1)+3;
        WaitSecs(1.5);
    elseif ((Mouse(trial_counter,5) == 1)&&(TP == 1))
        % Reject Press, TP
        % 0 Reward + 200 ms ITI
        WaitSecs(0.2);
    elseif ((Mouse(trial_counter,5) == 1)&&(TP == 0)&&(Counter ~= rejectcount))
        % Reject Press, TA, hasn't reached threshold
        % 0 Reward + 200 ms ITI
        Counter = Counter + 1;
        WaitSecs(0.2);
    elseif ((Mouse(trial_counter,5) == 1)&&(TP == 0)&&(Counter == rejectcount))
        % Reject Press, TA, reached threshold
        % +3 Reward + 1.5 s ITI
        Counter = 0;
        Reward(trial_counter,1) = Reward(trial_counter,1)+3;
        WaitSecs(1.5);
    else
        fprintf('debugg');
    end 
    if ((Mouse(trial_counter,3) == 1))
        Result.Trial_Data.ButtonPressed{trial_counter,1} = 'Accept ';
    elseif ((Mouse(trial_counter,5) == 1))
        Result.Trial_Data.ButtonPressed{trial_counter,1} = 'Reject ';
    else
        Result.Trial_Data.ButtonPressed{trial_counter,1} = 'Nothing';
    end
    Result.Trial_Data.FractalsName(trial_counter,:) = trial(1,4:12);
    Result.Trial_Data.DS(trial_counter,1) = trial(1,2);
    if ((trial(1,1) == 4)||(trial(1,1) == 3))
        Result.Trial_Data.ValuePerceptual{trial_counter,1} = 'Value     ';
    else
        Result.Trial_Data.ValuePerceptual{trial_counter,1} = 'Perceptual';    
    end
    if ((trial(1,1) == 1)||(trial(1,1) == 3))
        Result.Trial_Data.TATP{trial_counter,1} = 'TP';
    else
        Result.Trial_Data.TATP{trial_counter,1} = 'TA';    
    end
    Result.Trial_Data.MousePosition{trial_counter,1} = Mouse(trial_counter,1:2);
end
Screen('CloseAll');
save('Result');


% Functions
% search if the clicked position is on fractal or not
function [check] = whereclicked(clickpos, fractpos, goodbad_index, DS)
% check = 0 ==> blank area clicked, check = 1 ==> bad fractal clicked, check = 2 ==> good fractal clicked
click = 0 ;
goodclick = 0;
for i = 1:DS
    if ((clickpos(1) > fractpos(i,1))&&(clickpos(1) < fractpos(i,3))&&(clickpos(2) > fractpos(i,2))&&(clickpos(2) < fractpos(i,4)))
        click = 1;
    end
end
i = goodbad_index;
if (i~=0)
    if ((clickpos(1) > fractpos(i,1))&&(clickpos(1) < fractpos(i,3))&&(clickpos(2) > fractpos(i,2))&&(clickpos(2) < fractpos(i,4)))
        goodclick = 1;
    end
end
if((click == 1)&&(goodclick == 1))
    check = 2;
elseif((click == 1)&&(goodclick == 0))
    check = 1;
else
    check = 0;
end
end