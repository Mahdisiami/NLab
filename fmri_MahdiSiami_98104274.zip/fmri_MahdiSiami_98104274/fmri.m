clc; 
close all; 
clear all;

dataFile = 'neuro data2';

A = readtable(dataFile);

type1 = 'visual standard stimulus presentation';
type2 = 'visual oddball stimulus presentation';
type3 = 'behavioral response time following visual oddball stimulus onset';

onset_1 = [];
onset_2 = [];
onset_3 = [];

itrial_1 = 1;
itrial_2 = 1;
itrial_3 = 1;

for itrial = 1:size(A, 1)
    if strcmpi(A{itrial, 3}, type1) % t1
        onset_1(itrial_1) = str2double(A{itrial, 1});
        itrial_1 = itrial_1 + 1;
    elseif strcmpi(A{itrial, 3}, type2) % t2
        onset_2(itrial_2) = str2double(A{itrial, 1});
        itrial_2 = itrial_2 + 1;
    else % t3
        
        onsetValue = A{itrial, 1};
        onset_3(itrial_3, 1) = str2double(onsetValue) + 0.2; % onset
        onset_3(itrial_3, 2) = str2double(A{itrial, 2}) - 0.2; % duration
        onset_3(itrial_3, 3) = 1; % amps
        itrial_3 = itrial_3 + 1;
        
        %{
        onsetValue = A{itrial, 1};
        if isnumeric(onsetValue) && ~isnan(onsetValue)
            onset_3(itrial_3, 1) = str2double(onsetValue) + 0.2; % onset
            onset_3(itrial_3, 2) = double(A{itrial, 2}) - 0.2; % duration
            onset_3(itrial_3, 3) = 1; % amps
            itrial_3 = itrial_3 + 1;
        end
        %}
    end
end

% Write
writematrix(onset_1, 't1.txt', 'Delimiter', 'tab')
writematrix(onset_2, 't2.txt', 'Delimiter', 'tab')
writematrix(onset_3, 't3.txt', 'Delimiter', 'tab')
