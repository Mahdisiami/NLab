clc;
clear all;
close all;
load('Q5data.mat')

All(find(isnan(All(:,6))),:) = [];

trial = zeros(80,4);


for i = 1:length(All(:,1))
    if (All(i,9)==2 | All(i,9)==1)
    trial(All(i,2),1) = trial(All(i,2),1)+All(i,6);
    trial(All(i,2),2) = trial(All(i,2),2)+1; 
    end
end


for i = 1:length(trial(:,1))
    trial(i,3) = trial(i,1)/trial(i,2); 
    trial(i,4) = i;
end
trial(find(isnan(trial(:,3))),:) = [];
trial(find(trial(:,2)==1),:) = [];

x = trial(:,4);
figure
scatter(x,trial(:,3))
title('Reward-Associated trial average respose time')
xlabel('Trial')
ylabel('Average Respose Time(s)')

%////////////////////////////

trial = zeros(80,4);

for i = 1:length(All(:,1))
    if (All(i,9)==0)
    trial(All(i,2),1) = trial(All(i,2),1)+All(i,6);
    trial(All(i,2),2) = trial(All(i,2),2)+1; 
    end
end


for i = 1:length(trial(:,1))
    trial(i,3) = trial(i,1)/trial(i,2); 
    trial(i,4) = i;
end


trial(find(isnan(trial(:,3))),:) = [];
trial(find(trial(:,2)==1),:) = [];

x =trial(:,4);
figure
scatter(x,trial(:,3))
title('Loss-Associated trial average respose time')
xlabel('Trial')
ylabel('Average Respose Time(s)')
clear fitt i trial x;

% ///////////////////////// 

accuracy = zeros(80,4);

for i = 1:length(All(:,1))
    if (All(i,9)==2 | All(i,9)==1)
        accuracy(All(i,2),1) = accuracy(All(i,2),1)+All(i,7);
        accuracy(All(i,2),2) = accuracy(All(i,2),2)+1; 
    end
end


for i = 1:length(accuracy(:,1))
    accuracy(i,3) = accuracy(i,1)/accuracy(i,2); 
    accuracy(i,4) = i;
end

accuracy(find(isnan(accuracy(:,3))),:) = [];
accuracy(find(accuracy(:,2)==1),:) = [];
accuracy(find(accuracy(:,2)==0),:) = [];

x =accuracy(:,4);
figure
scatter(x,accuracy(:,3))
title('Reward-Associated accuracy')
xlabel('Trial')
ylabel('Accuracy(%)')
% ////////////////////////////////////

accuracy = zeros(80,4);

for i = 1:length(All(:,1))
    if (All(i,9)==0)
        accuracy(All(i,2),1) = accuracy(All(i,2),1)+All(i,7);
        accuracy(All(i,2),2) = accuracy(All(i,2),2)+1; 
    end
end


for i = 1:length(accuracy(:,1))
    accuracy(i,3) = accuracy(i,1)/accuracy(i,2); 
    accuracy(i,4) = i;
end

accuracy(find(isnan(accuracy(:,3))),:) = [];
accuracy(find(accuracy(:,2)==1),:) = [];
accuracy(find(accuracy(:,2)==0),:) = [];

x =accuracy(:,4);

figure
scatter(x,accuracy(:,3))

title('Loss-Associated accuracy')
xlabel('Trial')
ylabel('Accuracy(%)')

