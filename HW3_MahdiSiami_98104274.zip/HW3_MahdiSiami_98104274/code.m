%% HW3 

clc;
close all;
clear all;
load('matlabdataset.mat')
%%  Q2

n = length(ST);
Y = ST;
X1 = DS;
X2 = TD;
linmod = fitlm([X1,X2],Y);
beta0 = linmod.Coefficients{1,1}
beta1 = linmod.Coefficients{2,1}
beta2 = linmod.Coefficients{3,1}
yhat = beta0 + beta1.*DS + beta2.*TD;

SSE = sum((Y-yhat).^2);
MSE = SSE/(n-3);
epsilon = Y - yhat;
SSTO = sum((Y - mean(Y)).^2);
SSR = sum((yhat - mean(Y)).^2);
MSR = SSR/2;
Fstar = MSR/MSE;
fullmodel_Pvalue = fcdf(Fstar,2,n-3,'upper');
figure;
scatter(X1,Y)
hold on
plot(X1,beta0 + beta1.*X1)
title('Search Time vs Display Size')
xlabel('DS')
ylabel('ST')
figure;
scatter(X2,Y)
hold on
plot(X2,beta0 + beta2.*X2)
title('Search Time vs Training Duration')
xlabel('TD')
ylabel('ST')
figure;
x1fit = linspace(3,9,100);
x2fit = linspace(1,5,100);
[X1FIT,X2FIT] = meshgrid(x1fit,x2fit);
YFIT = beta0 + beta1*X1FIT + beta2*X2FIT;
mesh(X1FIT,X2FIT,YFIT)
xlabel('DS')
ylabel('TD')
zlabel('ST')
title('Search Time vs Display Size and Training Duration')
hold on
scatter3(X1,X2,Y)
hold off

%% Q3

figure;
qqplot(linmod.Residuals{:,1})
figure;
subplot(2,1,1)
scatter(linmod.Variables{:,1},linmod.Residuals{:,1})
hold on
plot(3:9,zeros(1,7),'color','r','LineWidth',1)
title('Residuals vs DisplaySize')
ylabel('Residual')
subplot(2,1,2)
scatter(linmod.Variables{:,2},linmod.Residuals{:,1})
hold on
plot(1:5,zeros(1,5),'color','r','LineWidth',1)
title('Residuals vs TD')
ylabel('Residual')
%% Q4
linmod1 = fitlm(X1,Y);
linmod2 = fitlm(linmod.Residuals{:,1},X2);
linmod3 = fitlm(X2,Y);
linmod4 = fitlm(linmod.Residuals{:,1},X1);
%% Q5
figure;
qqplot(ST)
title('Search Time Distribution(Not Normal)')
ylabel('ST(s)')
trans = 1./ST;
figure;
qqplot(trans)
title('Search Time Distribution(Normal)')
ylabel('ST(s)')
linmod5 = fitlm([X1,X2],trans);
beta0trans = linmod5.Coefficients{1,1};
beta1trans = linmod5.Coefficients{2,1};
beta2trans = linmod5.Coefficients{3,1};
trans_hat = beta0trans + beta1trans.*DS + beta2trans.*TD;
epsilontrans = trans - trans_hat;
figure;
qqplot(epsilontrans)
title('epsilon_i in the transformed model is Normally Distributed')
ylabel('epsilon_i')
%% Q6
figure;
[~ , ~ , stats , ~] = anovan(ST,[TD,DS])
[Tukey , ~ , ~ , Name1] = multcompare(stats,'CType','hsd');
Bonferroni = multcompare(stats,'CType','bonferroni');
Scheffe = multcompare(stats,'CType','scheffe');
%% Q7
anovan(ST,[SJ,TD,DS])
